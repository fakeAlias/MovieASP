﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinalAssignment.Models.Database
{
    public class TheaterDAO
    {
    }
}